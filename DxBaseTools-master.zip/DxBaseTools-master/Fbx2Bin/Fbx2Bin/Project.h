#pragma once


#include "resource.h"
#include "Scene.h"
#include "GameStage.h"
#include "Character.h"
