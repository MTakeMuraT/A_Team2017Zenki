#pragma once


// CDxWindow

class CDxWindow : public CWnd
{
	DECLARE_DYNAMIC(CDxWindow)

public:
	CDxWindow();
	virtual ~CDxWindow();

protected:
	DECLARE_MESSAGE_MAP()
};


