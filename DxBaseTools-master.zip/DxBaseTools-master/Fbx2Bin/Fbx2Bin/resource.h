//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ �Ő������ꂽ�C���N���[�h �t�@�C���B
// Fbx2Bin.rc �Ŏg�p
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_FBX2BIN_FORM                101
#define IDR_MAINFRAME                   128
#define IDR_Fbx2BinTYPE                 130
#define IDC_EDIT_DIRECTORY              1000
#define IDC_EDIT_FBXFILENAME            1001
#define IDC_BUTTON_READFILE             1002
#define IDC_EDIT_SCALE                  1003
#define IDC_EDIT_MESHID                 1004
#define IDC_EDIT_BINFILENAME_EXT        1005
#define IDC_EDIT_BINFILEHEADER          1006
#define IDC_BUTTON_SAVEFILE             1007
#define IDC_EDIT_BINFILENAME            1008
#define IDC_CHECK1                      1009
#define IDC_CHECK_IS_SCALING            1009
#define IDC_BUTTON_SAVEFILE_SKIN        1010
#define IDC_EDIT_ANIME_START            1011
#define IDC_EDIT_ANIME_END              1012
#define IDC_EDIT_ANIME_SAMPLE           1013
#define IDC_BUTTON_RUN_SKIN             1014
#define IDC_EDIT_ANIME_SAMPLE2          1015
#define IDC_EDIT_ANIME_SAMPLE_SPAN      1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
