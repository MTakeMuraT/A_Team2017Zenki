#include "stdafx.h"


namespace basedx11{

}
// end basedx11
